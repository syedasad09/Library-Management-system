#include <iostream>
#include <map>

using namespace std;

void management(void){
	string password;
	cout<<"Enter your Password: ";
	cin>>password;
	  if (password != "raza") {
        cout << "Passwords do not match." << endl;
        exit(0);
    }
    else if(password == "raza"){
	
    cout << "Sign up successful!\n\n\n" << endl;
    
}
}

void function(void){

    string username, password, confirmPassword;
    cout<<"\t\t\t\t *********************************************************\n";
    cout<<"\t\t\t\t\t ---------------- SIGN UP ---------------\n";
    cout<<"\t\t\t\t *********************************************************\n";
    cout << "\nEnter a username: ";
    cin>>username;
    
    cout << "Enter a password: ";
    cin>>password;
    
    cout << "Confirm your password: ";
    cin>>confirmPassword;
    
    if (password != confirmPassword) {
        cout << "Passwords do not match." << endl;
        exit(0);
    }
    else if(password == confirmPassword){
	
    cout << "Sign up successful!\n\n\n" << endl;
    
}
}

void exit();
void function1(){    
    string name;
    string email;
    string age;

    cout<<"\t\t\t\t *********************************************************\n";
    cout << "\t\t\t\t\t ------ Welcome to User Registration ------\n";
    cout<<"\t\t\t\t *********************************************************\n\n";
   
    cout << "Enter your name: ";
  cin>>name;

    cout << "Enter your age: ";
    cin>>age;

    cout << "Enter your email: ";
    cin>>email;

   
   
    cout << "\nName: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Email: " << email << endl; 
	cout<<"Your Registration Successful";  
}
struct Book {
    string title;
    string author;
    int year;
    bool isAvailable;
};
void issueBook(Book &book, string user) {
	
    if (book.isAvailable) {
        book.isAvailable = false;
        cout << "Book issued to " << user << ": " << book.title << " by " << book.author << " (" << book.year << ")" << endl;
    } else {
        cout << "Sorry, " << book.title << " is not available right now." << endl;
    }
}
Book getBookInput() {
    Book book;
    cout << "Enter book title: "<<endl;
    cin>>book.title;
    cout << "Enter book author: "<<endl;
    cin>>book.author;
    cout << "Enter book publication year: "<<endl;
    cin>>book.year;
    book.isAvailable = true;
    return book;
}
string getUserInput() {
    string user;
    cout << "Enter your name: ";
    cin>>user;
    return user;
}
const int MAX_DAYS = 14;
const double DAILY_FINE = 0.50;


double calculateFine(int daysLate) {
    if (daysLate <= 0) {
        return 0;
    } else {
        return daysLate * DAILY_FINE;
    }
}


bool isBookOverdue(int daysLate) {
    return (daysLate > MAX_DAYS);
}


double calculateAdditionalFine(int daysLate) {
    if (isBookOverdue(daysLate)) {
        return calculateFine(daysLate - MAX_DAYS);
    } else {
        return 0;
    }
}


void displayFinePayment(int daysLate) {
    double fine = calculateFine(daysLate);
    double additionalFine = calculateAdditionalFine(daysLate);

    cout << fixed;

    if (daysLate <= 0) {
        cout << "Your book is not yet overdue." << endl;
    } else {
        cout << "Your book is " << daysLate << " days overdue." << endl;
        cout << "Your fine payment is $" << fine << "." << endl;

        if (isBookOverdue(daysLate)) {
            cout << "Your additional fine payment is $" << additionalFine << "." << endl;
        }
    }
}
void function55(void){
	exit(0);
}
void student(void){
	  cout<<"\t\t\t\t *********************************************************\n";
	cout<<"\t\t\t\t\t ----------------HOME PAGE---------------\n";
	cout<<"\t\t\t\t *********************************************************\n\n";
	
	string a;
	cout<<"1.Registration Form "<<endl;
	cout<<"2.Book Issue "<<endl;
	cout<<"3.Fine "<<endl;
	cout<<"4.Exit "<<endl;
	cout<<"open: ";
cin>>a;
	if(a == "1"){
	function1();
		
}
else if(a=="2"){
	cout<<"\t\t\t\t *********************************************************\n";
	cout<<"\t\t\t\t\t ----------WELCOME TO BOOK ISSUE--------\n";
	cout<<"\t\t\t\t *********************************************************\n\n";
    Book book = getBookInput();
    string user = getUserInput();
    issueBook(book, user);
    
}
else if(a=="3"){
    cout<<"\t\t\t\t *********************************************************\n";
	cout<<"\t\t\t\t\t -------------WELCOME TO FINE-------------\n";
	cout<<"\t\t\t\t *********************************************************\n\n";
 int daysLate;
    cout << "Enter number of days late: ";
    cin >> daysLate;
    displayFinePayment(daysLate);
}
else if(a=="4"){
    	function55();
	}
    	
}
struct User {
    string username;
    string password;
    string name;
    string address;
};

struct Item {
    string name;
    string author;
    string category;
    int quantity;
};

map<string, User> users;
map<string, Item> items;

void createUser() {
    User user;
    cout << "Enter username: ";
    cin >> user.username;
    cout << "Enter password: ";
    cin >> user.password;
    cout << "Enter name: ";
    cin.ignore();
    getline(cin, user.name);
    cout << "Enter address: ";
    getline(cin, user.address);

    users[user.username] = user;

    cout << "User created successfully!" << endl;
}

void deleteUser() {
    string username;
    cout << "Enter username to delete: ";
    cin >> username;

    if (users.find(username) != users.end()) {
        users.erase(username);
        cout << "User deleted successfully!" << endl;
    } else {
        cout << "User not found!" << endl;
    }
}

void updateUser() {
    string username;
    cout << "Enter username to update: ";
    cin >> username;

    if (users.find(username) != users.end()) {
        User& user = users[username];
        cout << "Enter new password: ";
        cin >> user.password;
        cout << "Enter new name: ";
        cin.ignore();
        getline(cin, user.name);
        cout << "Enter new address: ";
        getline(cin, user.address);

        cout << "User updated successfully!" << endl;
    } else {
        cout << "User not found!" << endl;
    }
}

void addItem() {
    Item item;
    cout << "Enter item name: ";
    cin.ignore();
    getline(cin, item.name);
    cout << "Enter author: ";
    getline(cin, item.author);
    cout << "Enter category: ";
    getline(cin, item.category);
    cout << "Enter quantity: ";
    cin >> item.quantity;

    items[item.name] = item;

    cout << "Item added successfully!" << endl;
}

void deleteItem() {
    string itemName;
    cout << "Enter item name to delete: ";
    cin.ignore();
    getline(cin, itemName);

    if (items.find(itemName) != items.end()) {
        items.erase(itemName);
        cout << "Item deleted successfully!" << endl;
    } else {
        cout << "Item not found!" << endl;
    }
}

void generateReport() {
    // Implementation of report generation
    cout << "Generating report..." << endl;
}

void showMenu() {
    cout << "Library Management System" << endl;
    cout << "1. Create User" << endl;
    cout << "2. Delete User" << endl;
    cout << "3. Update User" << endl;
    cout << "4. Add Item" << endl;
    cout << "5. Delete Item" << endl;
    cout << "6. Generate Report" << endl;
    cout << "0. Exit" << endl;
    cout << "Enter your choice: ";
}

void functionbat(void){
    int choice;
    while (true) {
        showMenu();
        cin >> choice;

        switch (choice) {
            case 1:
            		cout<<"\t\t\t\t *********************************************************\n";
    	cout<<"\t\t\t\t\t-----------CREATE USER ACCOUNT------------\n";
    	cout<<"\t\t\t\t *********************************************************\n\n";
                createUser();
                break;
            case 2:
            		cout<<"\t\t\t\t *********************************************************\n";
    	cout<<"\t\t\t\t\t-----------DELETE USER ACCOUNT------------\n";
    	cout<<"\t\t\t\t *********************************************************\n\n";
                deleteUser();
                break;
            case 3:
            		cout<<"\t\t\t\t *********************************************************\n";
    	cout<<"\t\t\t\t\t-----------UPDATE USER ACCOUNT------------\n";
    	cout<<"\t\t\t\t *********************************************************\n\n";
                updateUser();
                break;
            case 4:
            		cout<<"\t\t\t\t *********************************************************\n";
    	cout<<"\t\t\t\t\t------------------ADD ITEM-------------------\n";
    	cout<<"\t\t\t\t *********************************************************\n\n";
                addItem();
                break;
            case 5:
            	cout<<"\t\t\t\t *********************************************************\n";
    	cout<<"\t\t\t\t\t------------------DELETE ITEM----------------\n";
    	cout<<"\t\t\t\t *********************************************************\n\n";
                deleteItem();
                break;
            case 6:
                generateReport();
                break;
            case 0:
                cout << "Exiting program..." << endl;
                exit(0);
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }

}
void library(void){
	cout<<"\t\t\t\t *********************************************************\n";
	cout<<"\t\t\t\t\t---------LIBRARY MANAGEMENT SYSTEM----------\n";
	cout<<"\t\t\t\t *********************************************************\n\n";
	string e;
	cout<<"1.Student sign up "<<endl;
	cout<<"2.Librarian "<<endl;
	cout<<"open:";
	cin>>e;
	
	if(e=="1"){
		function();
		student();
	}
    else if(e=="2"){
    	 cout<<"\t\t\t\t *********************************************************\n";
    cout<<"\t\t\t\t\t ---------------- SIGN UP ---------------\n";
    cout<<"\t\t\t\t *********************************************************\n";
    	management();
    	cout<<"\t\t\t\t *********************************************************\n";
	cout<<"\t\t\t\t\t ----------------HOME PAGE---------------\n";
	cout<<"\t\t\t\t *********************************************************\n\n";
    	functionbat();
	}
    
}
int main(){

	library();
    return 0;
}




